package day3;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Categories {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver=new  ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		driver.get("https://ineuron-courses.vercel.app/login");
		
		driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(10));
		driver.findElement(By.xpath("//input[contains(@name,'email1')]")).sendKeys("ineuron@ineuron.ai");
		driver.findElement(By.xpath("//input[contains(@name,'password1')]")).sendKeys("ineuron");
		driver.findElement(By.xpath("//button[contains(@type,'submit')]")).click();
		String parent=driver.getWindowHandle();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Actions act=new Actions(driver);
		WebElement ele=driver.findElement(By.xpath("//span[text()='Manage']"));
		act.moveToElement(ele).perform();
		
		
		driver.findElement(By.xpath("//span[text()='Manage Categories']")).click();
		Set<String> allWindowHandle=driver.getWindowHandles();
		for(String child:allWindowHandle)
		{
			
			if(!child.equals(parent))
			{
				
				driver.switchTo().window(child);
				driver.findElement(By.xpath("//button[text()='Add New Category ']")).click();
				
			}
			
			
		}
		Alert alt=driver.switchTo().alert();
		alt.sendKeys("something");
		alt.accept();
		driver.findElement(By.xpath("//td[text()='something']//following::button[1]")).click();
		//Alert alt1=driver.switchTo().alert();
		driver.findElement(By.xpath("//button[text()='Delete']")).click();
		
		
		
		
		
		

	}

}
